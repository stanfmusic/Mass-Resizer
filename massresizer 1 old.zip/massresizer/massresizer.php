<?php
/**
 * Plugin Name: Mass Resizer
 * Description: Plugin for bulk resizing & converting to WebP images through the media library.
 * Version: 2.7beta
 * Author: Stan Furtovsky Pro
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html
 * Text Domain: mass-resizer
 * 
 * © 2024 Stan Furtovsky Pro. All rights reserved.
 * This plugin is licensed under the GPLv2 or later.
 */

// Load text domains
function massresize_load_textdomain() {
    load_plugin_textdomain('mass-resizer', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'massresize_load_textdomain');

// Register settings
function massresize_register_settings() {
    add_option('massresize_webp', false);
    add_option('massresize_crop', false);
    add_option('massresize_compression_percentage', 80);
    add_option('massresize_max_width', 1024);
    add_option('massresize_max_height', 800);
    register_setting('massresize_options_group', 'massresize_max_width', 'massresize_validate_width');
    register_setting('massresize_options_group', 'massresize_max_height', 'massresize_validate_height');
    register_setting('massresize_options_group', 'massresize_webp', 'massresize_validate_webp');
    register_setting('massresize_options_group', 'massresize_compression_percentage', 'massresize_validate_procents');
    register_setting('massresize_options_group', 'massresize_crop', 'massresize_validate_crop');
}
add_action('admin_init', 'massresize_register_settings');

// Validation functions
function massresize_validate_width($input) {
    $input = intval($input);
    return ($input > 0 && $input <= 5000) ? $input : 1024; // Set default value if input is invalid
}

function massresize_validate_height($input) {
    $input = intval($input);
    return ($input > 0 && $input <= 5000) ? $input : 800; // Set default value if input is invalid
}

function massresize_validate_webp($input) {
    return filter_var($input, FILTER_VALIDATE_BOOLEAN);
}
function massresize_validate_crop($input) {
    return filter_var($input, FILTER_VALIDATE_BOOLEAN);
}

function massresize_validate_procents($input) {
    $input = intval($input);
    return ($input >= 0 && $input <= 100) ? $input : 100; // Set default value if input is invalid
}

// Options page
function massresize_options_page() {

    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    $plugin_data = get_plugin_data( __FILE__ ); // Получаем данные о плагине
    $version = $plugin_data['Version']; 
    $author = $plugin_data['Author']; 
    $massresizer_logo_url = plugin_dir_url(__FILE__) . 'assets/massresizer_logo.jpg';
?>
    <div>
        <h2><?php _e('Mass Resizer Settings', 'mass-resizer'); ?></h2>
        <p><?php printf(__('Version: %s', 'mass-resizer'), esc_html($version)); ?></p>
        <p><?php printf(__('Author: %s', 'mass-resizer'), esc_html($author)); ?></p>
        <?php if ($massresizer_logo_url) {
             echo '<img src="' . esc_url($massresizer_logo_url) . '" alt="mass resize logo" style="max-width: 200px; height: auto; margin-bottom: 20px;" />';
        }?>
        
        <form method="post" action="options.php">
            <?php settings_fields('massresize_options_group'); ?>
            <table>
                <tr valign="top">
                    <th scope="row"><?php _e('Enable image cropping', 'mass-resizer'); ?></th>
                    <td>
                        <input type="checkbox" id="massresize_crop" name="massresize_crop" value="1" <?php checked(get_option('massresize_crop'), true); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('Maximum image width', 'mass-resizer'); ?></th>
                    <td><input type="number" name="massresize_max_width" value="<?php echo esc_attr(get_option('massresize_max_width')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('Maximum image height', 'mass-resizer'); ?></th>
                    <td><input type="number" name="massresize_max_height" value="<?php echo esc_attr(get_option('massresize_max_height')); ?>" /></td>
                </tr>
                <tr valign="top">
                <tr valign="top">
                    <th scope="row"><?php _e('Enable WebP Compression', 'mass-resizer'); ?></th>
                    <td>
                    <input type="checkbox" id="massresize_webp" name="massresize_webp" value="1" <?php checked(get_option('massresize_webp'), true); ?> />
                    </td>
                    </tr>

                    <tr valign="top" id="compression_percentage_row" style="display: <?php echo get_option('massresize_webp') ? 'table-row' : 'none'; ?>;">
                    <th scope="row"><?php _e('Compression Percentage', 'mass-resizer'); ?></th>
                    <td>
                    <input type="number" name="massresize_compression_percentage" min="0" max="100" value="<?php echo esc_attr(get_option('massresize_compression_percentage', 80)); ?>" />
                    <p><?php _e('Set the compression level for WebP images (0-100%)', 'mass-resizer'); ?></p>
                    </td>
                    </tr>

                    <script type="text/javascript">
                        document.addEventListener('DOMContentLoaded', function() {
                            const webpCheckbox = document.getElementById('massresize_webp');
                            const compressionRow = document.getElementById('compression_percentage_row');

                             // Show or hide the compression percentage field based on checkbox state
                             webpCheckbox.addEventListener('change', function() {
                                compressionRow.style.display = this.checked ? 'table-row' : 'none';
                            });
                        });
                    </script>
            </table>
            <input type="submit" value="<?php _e('Save Settings', 'mass-resizer'); ?>" />
        </form>
    </div>



    <h2>Support the Plugin</h2>
    <p>If you enjoy using this plugin and would like to support its continued development, consider making a donation.
    <br>You can contribute in cryptocurrency or transfer funds to my bank account in EU. Please mention "donate" in the transfer description.</bи>
    <p><strong>Cryptocurrency donations:</strong></p>
    <ul>
        <li><strong>Bitcoin:</strong> 1wEPRrCsA7fUza8SjmaeAztgzrwN5Yunu</li>
        <li><strong>USDT(TRC20):</strong> TR5LTYdgNoPBwn38ECFNt5aUZWffvm1oh6</li>
        <li><strong>USDT(ERC20):</strong> 0xc44ee3d0e680eb582b044219f82031b00f3ffed5</li>
    </ul>
    <p><strong>EU Bank Account Transfer:</strong></p>
    <ul>
        <li><strong>Name:</strong> Stanislav Furtovskiy</li>
        <li><strong>Account Number:</strong> LT843500010016679999</li>
        <li><strong>SWIFT/BIC:</strong> EVIULT2VXXX</li>
        <li><strong>Bank:</strong> Paysera LT, UAB</li>
        <li><strong>Telegram:</strong> <a href="https://t.me/stanfmusic">@stanfmusic</a></li>
        <li><strong>E-mail:</strong> <a href="mailto:furtovsky@gmail.com">furtovsky@gmail.com</a></li>
    </ul>
    <p>Thank you for your support!</p>


<?php
}

// Add admin menu for settings page
function massresize_add_admin_menu() {
    add_options_page(
        'Mass Resizer Settings',
        'Mass Resizer',
        'manage_options',
        'mass-resizer',
        'massresize_options_page'
    );
}
add_action('admin_menu', 'massresize_add_admin_menu');

// Function to resize an image by ID
function massresize_crop_by_id($image_id) {
    $image_path = get_attached_file($image_id);
    
    if (!file_exists($image_path)) {
        return sprintf(__('File not found for ID: %d', 'mass-resizer'), $image_id);
    }

    list($width, $height) = getimagesize($image_path);

    // Get the maximum size settings
    $max_width = get_option('massresize_max_width', 1024);
    $max_height = get_option('massresize_max_height', 800);
    $webp_percentage = get_option('massresize_compression_percentage', 80);
    $webp_switch = get_option ('massresize_webp', false);
    $crop_switch = get_option ('massresize_crop', false);

    // Check first condition: height is greater than width and greater than the maximum height
    if ($crop_switch && ($height > $width && $height > $max_height)) {
        $new_height = $max_height;
        $new_width = intval(($width / $height) * $new_height); // Proportional width adjustment
    } 
    // Check second condition: width is greater than the maximum width
    elseif ($crop_switch && ($width > $max_width)) {
        $new_width = $max_width;
        $new_height = intval(($height / $width) * $new_width); // Proportional height adjustment
    } 
    else {
            // Если не надо кропить, проверяем надо ли конвертировать в формат WebP
            if ($webp_switch) {
                // Здесь код для конвертации в формат WebP
                $massresizer_error = massresize_convert_to_webp ($image_id, $webp_percentage, $image_path);
                if (strpos($massresizer_error, 'Error') !== false) {

                    
                    return $massresizer_error;

                }
                return sprintf(__('Image converted to WebP format. Current dimensions: %dx%d', 'mass-resizer'), $width, $height);
            }

        return sprintf(__('No need to resize photo. Current dimensions: %dx%d', 'mass-resizer'), $width, $height);
    }

    // Load the image and resize it
    $image_editor = wp_get_image_editor($image_path);
    if (is_wp_error($image_editor)) {
        return sprintf(__('Error loading image for ID: %d', 'mass-resizer'), $image_id);
    }

    $image_editor->resize($new_width, $new_height, true);
    $saved = $image_editor->save($image_path);
    
    if (is_wp_error($saved)) {
        return sprintf(__('Error resizing for ID: %d', 'mass-resizer'), $image_id);
    }

    // Update metadata
    $metadata = wp_get_attachment_metadata($image_id);
    $metadata['width'] = $new_width;
    $metadata['height'] = $new_height;
    wp_update_attachment_metadata($image_id, $metadata);


    if ($webp_switch) {
        // Здесь код для конвертации в формат WebP
        $massresizer_error = massresize_convert_to_webp($image_id, $webp_percentage, $image_path);
        if (strpos($massresizer_error, 'Error') !== false) {
            
            return $massresizer_error;
        }
        $message = sprintf(__('Image converted to WebP format. Current dimensions: %dx%d', 'mass-resizer'), $new_width, $new_height);
    } else {
        $message = sprintf(__('Image dimensions for ID: %d changed to %dx%d', 'mass-resizer'), $image_id, $new_width, $new_height);
    }
    
    return $message;
    
}

// Add bulk action to the media library
function massresize_register_custom_bulk_actions($bulk_actions) {
    $bulk_actions['bulk_image_resize'] = __('Resize Images', 'mass-resizer');
    return $bulk_actions;
}
add_filter('bulk_actions-upload', 'massresize_register_custom_bulk_actions');

// Execute action for selected images
function massresize_handle_custom_bulk_action($redirect_to, $action, $post_ids) {
    if ($action !== 'bulk_image_resize') {
        return $redirect_to;
    }

    $messages = []; // Массив для хранения сообщений

    foreach ($post_ids as $post_id) {
        $result = massresize_crop_by_id($post_id);
        error_log($result);
        // Добавляем результат в массив сообщений
        $messages[] = $result; // Добавляем результат, который уже есть в $result
    
        // Очищаем объект редактора изображения из памяти
        unset($image_editor);       
    
    }
    // Очищаем кэш WordPress
    wp_cache_flush();
    // Сохраняем сообщения в транзиент
    set_transient('massresize_conversion_messages', $messages, 60); // Храним 60 секунд
    return $redirect_to;
}


// Function convertion image (JPEG&PNG) to webp
function massresize_convert_to_webp($image_id, $webp_percentage, $image_path) {
    // Получаем информацию об изображении
    $image_info = getimagesize($image_path);

    // Проверяем, удалось ли получить информацию
    if ($image_info === false) {
        return sprintf(__('Failed to get image information for ID: %d', 'mass-resizer'), $image_id);
    }

    // Получаем MIME-тип
    $mime_type = $image_info['mime'];

    // Проверяем, что изображение в формате JPEG или PNG
    if (!in_array($mime_type, ['image/jpeg', 'image/png'])) {
        $massresizer_error = sprintf(__('Error! Invalid image format for ID: %d. Only JPEG and PNG are supported.', 'mass-resizer'), $image_id);
        
        return $massresizer_error;
    }        

    // Загружаем оригинальное изображение
    $image = wp_get_image_editor($image_path);
    if (is_wp_error($image)) {
        return sprintf(__('Error loading image for ID: %d', 'mass-resizer'), $image_id);
    }

    // Конвертация в WebP
    $dirname = pathinfo($image_path, PATHINFO_DIRNAME);
    $filename = pathinfo($image_path, PATHINFO_FILENAME);
    $webp_path = $dirname . '/' . $filename . '.webp';

    

    // Получаем путь для файла WebP
    $dirname = pathinfo($image_path, PATHINFO_DIRNAME);
    $filename = pathinfo($image_path, PATHINFO_FILENAME);
    $webp_path = $dirname . '/' . $filename . '.webp';

    // Проверка существования WebP по метаданным
    global $wpdb;
    $webpfile_name = basename($webp_path); // Извлекаем имя файла, например, test2.webp

    // Формируем SQL-запрос с подстановкой для поиска
    $sql_query = $wpdb->prepare(
        "SELECT post_id FROM {$wpdb->postmeta} 
        WHERE meta_key = '_wp_attached_file' 
        AND meta_value LIKE %s",
        '%' . $wpdb->esc_like($webpfile_name)
    );

    // Выводим отладочную информацию о запросе
    error_log("SQL Query: " . $sql_query);

    // Выполняем запрос и сохраняем результат
    $existing_webp_id = $wpdb->get_var($sql_query);

    // Проверка результата и вывод в лог
    if ($existing_webp_id) {
        error_log ("Found existing WebP ID: {$existing_webp_id}");
        wp_delete_attachment($existing_webp_id, true);
        error_log ("Error! File: {$webpfile_name} already exists in WordPress");
    } else {
        error_log ('No existing WebP file found for: ' . $webpfile_name);
    }








    $image->set_quality($webp_percentage); // Установка качества
    $saved = $image->save($webp_path, 'image/webp'); // Сохранение как WebP

    if (is_wp_error($saved)) {
        $massresizer_error = sprintf(__('Error saving WebP for ID: %d', 'mass-resizer'), $image_id);
        error_log($massresizer_error); // Записываем сообщение об ошибке в лог
        return $massresizer_error;
    }

    // Добавление нового изображения в медиабиблиотеку
    $attachment = [
        'guid'           => $webp_path,
        'post_mime_type' => 'image/webp',
        'post_title'     => sanitize_file_name($filename),
        'post_content'   => '',
        'post_status'    => 'inherit'
    ];

    // Вставляем в базу данных
    $new_image_id = wp_insert_attachment($attachment, $webp_path);

    // Обновляем метаданные
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $attach_data = wp_generate_attachment_metadata($new_image_id, $webp_path);
    wp_update_attachment_metadata($new_image_id, $attach_data);

    return sprintf(__('Converted image for ID: %d to WebP format with ID: %d', 'mass-resizer'), $image_id, $new_image_id);
}


// Вывод сообщений на странице админки
function massresize_log_admin_notice() {
    $messages = get_transient('massresize_conversion_messages');

    if ($messages) {
        $chunks = array_chunk($messages, 9); // Разбиваем массив на группы по 9 сообщений

        foreach ($chunks as $chunk) {
            echo '<div class="notice notice-success is-dismissible">';
            foreach ($chunk as $message) {
                echo '<p>' . esc_html($message) . '</p>'; // Выводим каждое сообщение
            }
            echo '</div>';
        }

        // Удаляем транзиент после отображения сообщений
        delete_transient('massresize_conversion_messages');
    }
}


// Подключаем функцию для вывода уведомлений
add_action('admin_notices', 'massresize_log_admin_notice');

// Подключаем обработчик массовых действий
add_filter('handle_bulk_actions-upload', 'massresize_handle_custom_bulk_action', 10, 3);
